# HUSTOJ Theme MDUI

## Author

**HUSTOJ Theme MDUI** © [Baoshuo](https://github.com/renbaoshuo), Released under the [GPL-2.0](https://github.com/zhblue/hustoj/blob/master/trunk/web/gpl-2.0.txt) License.<br>

> [Personal Website](https://baoshuo.ren) · [Blog](https://blog.baoshuo.ren) · GitHub [@renbaoshuo](https://github.com/renbaoshuo) · Twitter [@renbaoshuo](https://twitter.com/renbaoshuo)
