<?php
	//oj-header.php
	$MSG_FAQ="چۈشەنچە & سوئال";
	$MSG_BBS="تور بەت";
	$MSG_HOME="باش بەت";
	$MSG_PROBLEMS="مەسىلىلەر";
	$MSG_STATUS="ھالەت";
	$MSG_RANKLIST="دەرىجە";
	$MSG_CONTEST="مۇسابىقە";
	$MSG_RECENT_CONTEST="يېقىنقى";
	$MSG_LOGOUT="چىقىش";
	$MSG_LOGIN="كىرىش";
	$MSG_LOST_PASSWORD="مەخپى نۇمۇر يۈتتى";
	$MSG_REGISTER="رويخەتكە ئىلىش";
	$MSG_ADMIN="باشقۇرغۇچى";
	$MSG_SYSTEM="System";
	$MSG_STANDING="مەرتىۋە";
	$MSG_STATISTICS="سىتاتىستىكا";
	$MSG_USERINFO="ئابونىت ئۇچۇرى";
	$MSG_MAIL="ئېلخەت";

	//status.php
	$MSG_Pending="كۈتۈۋاتىدۇ...";
	$MSG_Pending_Rejudging="قايتا تەكشۈرۈشنى كۈتۈۋاتىدۇ...";
	$MSG_Compiling="تەرجىمىلىنىۋاتىدۇ...";
	$MSG_Running_Judging="تەكشۈرۈشتە...";
	$MSG_Accepted="مۇبارەك بولسۇن";
	$MSG_Presentation_Error="چىقىرىش خاتا ";
	$MSG_Wrong_Answer="جاۋاپ خاتا";
	$MSG_Time_Limit_Exceed="ۋاقىت چەكتىن ئاشتى ";
	$MSG_Memory_Limit_Exceed="ساقلىغۇچ چەكتىن ئاشتى";
	$MSG_Output_Limit_Exceed="چىقىرىش چەكتىن ئاشتى";
	$MSG_Runtime_Error="يۈرۈش خاتا";
	$MSG_Compile_Error="تەرجىمە خاتا";
	$MSG_Runtime_Click="يۈرۈش خاتا";
	$MSG_Compile_Click="تەرجىمە خاتا";
	$MSG_Compile_OK="تەرجىمە تامام";
	$MSG_Click_Detail="تەپسىلاتىنى كۆرۈش";
	$MSG_Manual="قولدا تەكشۈرۈش";
 	$MSG_OK="تامام";
 	$MSG_Explain="ھالەت ۋە چۈشەندۈرۈش";

//fool's day
/*
if(date('m')==4&&date('d')==1&&rand(0,100)<10){
                 $MSG_Accepted="كاللىڭىزدا مەسىلە بار...ئالدامچىلار بايرىمىغا مۇبارەك";
	$MSG_Presentation_Error="كاللىڭىزدا مەسىلە بار...ئالدامچىلار بايرىمىغا مۇبارەك";
	$MSG_Wrong_Answer="كاللىڭىزدا مەسىلە بار...ئالدامچىلار بايرىمىغا مۇبارەك";
	$MSG_Time_Limit_Exceed="كاللىڭىزدا مەسىلە بار...ئالدامچىلار بايرىمىغا مۇبارەك";
	$MSG_Memory_Limit_Exceed="كاللىڭىزدا  مەسىلە بار...ئالدامچىلار بايرىمىغا مۇبارەك";
	$MSG_Output_Limit_Exceed="كاللىڭىزدا  مەسىلە بار...ئالدامچىلار بايرىمىغا مۇبارەك";
	$MSG_Runtime_Error="كاللىڭىزدا مەسىلە بار...ئالدامچىلار بايرىمىغا مۇبارەك";
	$MSG_Compile_Error="كاللڭىزدا  مەسىلە بار...ئالدامچىلار بايرىمىغا مۇبارەك";
	$MSG_Compile_OK="كاللىڭىزدا مەسىلە بار...ئالدامچىلار بايرىمىغا مۇبارەك";
}
*/
	$MSG_TEST_RUN="ئۈلگە مۇۋەپپىقىيەتلىك ئۆتتى";

	$MSG_RUNID="يوللىنىش نۇمۇرى";
	$MSG_USER="ئابۇنىت";
	$MSG_PROBLEM="مەسىلە";
	$MSG_RESULT="نەتىجە";
	$MSG_MEMORY="سېغىم";
	$MSG_TIME="ۋاقىت";
	$MSG_LANG="تىل";
	$MSG_CODE_LENGTH="كود ئۇزۇنلۇقى";
	$MSG_SUBMIT_TIME="تەكشۈرگەن ۋاقىت";

  	$MSG_MANUAL_CONFIRMATION="Manual Confirmation Pending...";
	$MSG_MC="ManualConfirm";

	//problemstatistics.php
	$MSG_PD="كۈتۈۋاتىدۇ";
	$MSG_PR="قايتا تەكشۈرۈشنى كۈتۈۋاتىدۇ...";
	$MSG_CI="تەرجىمىلىنىۋاتىدۇ";
	$MSG_RJ="تەرجىمىدە";
	$MSG_AC="مۇبارەك بولسۇن";
	$MSG_PE="چىقىرىش خاتا";
	$MSG_WA="جاۋاپ خاتا";
	$MSG_TLE="ۋاقىت چەكتىن ئاشتى";
	$MSG_MLE="ساقلىغۇچ چەكتىن ئاشتى";
	$MSG_OLE="چىقىرىش چەكتىن ئاشتى";
	$MSG_RE="يۈرۈش خاتا";
	$MSG_CE="تەرجىمە خاتا";
	$MSG_CO="تەرجىمە تامام";
	$MSG_TR=" سىناق ";
	$MSG_RESET=" قايتا ";

	//problemset.php
	$MSG_SEARCH="ئىزدەش";
	$MSG_PROBLEM_ID="مەسلە نۇمۇرى";
	$MSG_TITLE="ماۋزۇ";
	$MSG_SOURCE="مەنبە";
	$MSG_SUBMIT_NUM="تاپشۇرۇش نۇمۇرى";
	$MSG_SUBMIT="تاپشۇرۇش";
	$MSG_SHOW_OFF="ShowOff!";

	//submit.php
	$MSG_VCODE_WRONG="دەلىللەش كودى خاتا!";
	$MSG_LINK_ERROR="قەيەردىن بۇ ئۇلانمىنى تاپقىلى بولىدۇ؟ بۇ مەسىلە يوق.";
	$MSG_PROBLEM_RESERVED="سوئال چەكلەنگەن";
	$MSG_NOT_IN_CONTEST="سىز دەرھال تاپشۇرسىڭىز بولمايدۇ، چۈنكى سىز مۇسابىقىگە تەكلىپ قىلىنمىدىڭىز ياكى مۇسابىقىگە قاتناشمىدىڭىز!";
	$MSG_NOT_INVITED="مۇسابىقىگە تەكلىپ قىلىنمىدىڭىز";
	$MSG_NO_PROBLEM="بۇنداق سوئال يوق!";
	$MSG_NO_PLS="نامەلۇم پېروگىرامما تىلى!";
	$MSG_TOO_SHORT="كود بەك قىسقا!";
	$MSG_TOO_LONG="كود بەك ئۇزۇن!";
	$MSG_BREAK_TIME="سىز 10 سىكونت ئىچىدە بىر قېتىمدىن ئارتۇق تاپشۇرماسلىقىڭىز كېرەك...";

	//ranklist.php
	$MSG_Number="نۇمۇر";
	$MSG_NICK="نامى";
	$MSG_SOVLED="يېشلگىنى";
	$MSG_RATIO="نىسبىتى";
	$MSG_DAY="كۈنلۈك مەرتىۋە";
 	$MSG_WEEK="ھەپتىلىك مەرتىۋە";
	$MSG_MONTH="ئايلىق مەرتىۋە";
	$MSG_YEAR="يىللىق مەرتىۋە";
	//registerpage.php
	$MSG_USER_ID="ئابۇنىت نۇمۇرى";
	$MSG_PASSWORD="مەخپى نۇمۇر";
	$MSG_REPEAT_PASSWORD="مەخپى نۇمۇرنى قايتىلاش";
	$MSG_SCHOOL="مەكتەپ";
	$MSG_EMAIL="ئېلخەت";
	$MSG_REG_INFO="رويىخەت ئۇچۇرى";
	$MSG_VCODE="دەلىللەش كودى ";

	//problem.php
	$MSG_NO_SUCH_PROBLEM="بۇ سوئال شەخسىيگە تەۋە،كۆرۈشكە رۇخسەت يوق";
	$MSG_Description="مەزمۇن";
	$MSG_Input="كىرگۈزۈش";
	$MSG_Output= "چىقىرىش";
	$MSG_Sample_Input= "ئۈلگە كىرگۈزۈش";
	$MSG_Sample_Output= "ئۈلگە چىقىرىش";
	$MSG_Test_Input= "سىناق كىرگۈزۈش" ;
	$MSG_Test_Output= "سىناق چىقىرىش" ;
	$MSG_SPJ= "ئالاھېدە تەكشۈرۈش" ;
	$MSG_HINT= "كۆرسەتمە";
	$MSG_Source= "مەنبە";
	$MSG_Time_Limit="ۋاقىت چەكلىمىسى";
	$MSG_Memory_Limit="ساقلىغۇچ چەكلىمىسى";
	$MSG_EDIT= "تەھرىرلەش";
	$MSG_TESTDATA= "سىناق مەلۇمات";

	//admin menu
	$MSG_SEEOJ="باش بەت";
	$MSG_ADD=" قوشۇش  ";
	$MSG_MENU="تىزىملىك";
	$MSG_EXPLANATION="چۈشەنچە";
	$MSG_LIST=" جەدۋەل ";
	$MSG_NEWS=" ئۇقتۇرۇش ";
	$MSG_CONTENTS="مەزمۇن";
	$MSG_SAVE="ساقلاش";	
        $MSG_DELETED="Deleted";	
        $MSG_NORMAL="Normal";	

	$MSG_TEAMGENERATOR=" گورۇپ نۇمۇرى چىقارغۇچ ";
	$MSG_SETMESSAGE=" ئۇچۇر يېزىش ";
	$MSG_SETPASSWORD=" مەخپى نۇمۇر ئۆزگەرتىش ";
	$MSG_REJUDGE=" قايتا تەكشۈرۈش ";
	$MSG_PRIVILEGE=" ھوقۇقدار ";
	$MSG_GIVESOURCE=" مەنبە يېزىش ";
	$MSG_IMPORT=" يوللاش ";
	$MSG_EXPORT=" چىقىرىش ";
	$MSG_UPDATE_DATABASE=" سان-سىپىرنى يېڭىلاش ";
        $MSG_BACKUP_DATABASE="Backup Database";
	$MSG_ONLINE=" سىمدا ";
	$MSG_SET_LOGIN_IP="ئادېرسنى تەڭشەش IP ";
	$MSG_PRIVILEGE_TYPE="ھوقۇق تۈرى";
	$MSG_NEWS_MENU="Show in menu";

  //contest.php
  $MSG_PRIVATE_WARNING="مۇسابىقە باشلانمىدى ياكى سوئال شەخىسكە تەۋە";
  $MSG_PRIVATE_USERS_ADD="ئوقۇغۇچىلار ئوقۇش نومۇرىنى Excel دىن تەرتىپ بويىچە كۆچۈرۈپ كېلىپ، ئۇلاردىن ئوقۇش نومۇرى ئارقىلىق UID قىلىپ تىزىمغا ئالدۇرۇلغىلى بولىدۇ، Private نىڭ مۇسابىقىسىگە كىرىپ مەشغۇلات ۋە سىناق قىلغىلى بولىدۇ. ";
  $MSG_PLS_ADD="Ctrl + تاق چېكىش ئارقىلىق تاپشۇرغىلى بولىدىغان بارلىق تىللارنى تاللاڭ. ";
		$MSG_TIME_WARNING="مۇسابىقە باشلىنىشتىن بۇرۇن.";  
  $MSG_WATCH_RANK="بۇ يەرنى بىسىپ شەرەپ تاختىسىنى كۆرۈڭ";
  $MSG_NOIP_WARNING="مۇسابىقىسى ئاخىرلاشمىغىچە نەتىجىنى كۆرەلمەيسىز ".$OJ_NOIP_KEYWORD;
  $MSG_NOIP_NOHINT=$OJ_NOIP_KEYWORD." Contest does not show hint.";
	$MSG_SERVER_TIME="مۇلازىمىتېر ۋاقتى";
	$MSG_START_TIME="باشلىنىش ۋاقتى";
	$MSG_END_TIME="ئاياغلىشىش ۋاقتى";
	$MSG_CONTEST_ID="سىناق نۇمۇرى";
	$MSG_VIEW_ALL_CONTESTS="Show All Contests";
	$MSG_CONTEST_NAME="سىناق نامى";
	$MSG_CONTEST_STATUS="ھالەت";
	$MSG_CONTEST_OPEN="ئوچۇق";
	$MSG_CONTEST_CREATOR="ئىجادچى";
	$MSG_CONTEST_PENALTY="يىغىندى ۋاقىت";
	$MSG_IP_VERIFICATION="IP دەلىلەش";
	$MSG_CONTEST_SUSPECT1="كۆپ ID لىق IP ئادرېسى بار. ئەگەر مۇسابىقە، ئىمتىھان مەزگىلىدە ئوخشاش بىر كومپيۇتېردا نۇرغۇن ID نى زىيارەت قىلغان بولسىڭىز، بۇ ID خاتىرىلىنىدۇ. ";
	$MSG_CONTEST_SUSPECT2="كۆپلىگەن IP ئادرېسىغا ئىگە ID. ئەگەر مۇسابىقە، ئىمتىھان مەزگىلىدە باشقا بىر كومپيۇتېرغا ئالماشسا، ئۇ خاتىرىلىنىدۇ. ";
		
	$MSG_SECONDS="سېكۇنىت";
	$MSG_MINUTES="مىنۇت";
	$MSG_HOURS="سائەت";
	$MSG_DAYS="كۈن";
	$MSG_MONTHS="ئاي";
	$MSG_YEARS="يىل";
	
  $MSG_Public="ئاشكارە";
  $MSG_Private="خۇسۇسىي";
  $MSG_Running=" ئىلىپ بېرىلىۋاتىدۇ ";
  $MSG_Start=" باشلاش ";
  $MSG_End=" ئاخىرلاش ";
  $MSG_TotalTime=" جەمئىي";
  $MSG_LeftTime=" قېپ قالغىنى ";
  $MSG_Ended=" تۈگىگىنى ";
  $MSG_Login=" ئالدى بىلەن تىزىملاڭ ";
  $MSG_JUDGER=" تەكشۈرگۈچ ";

  $MSG_SOURCE_NOT_ALLOWED_FOR_EXAM="سىناق مەزگىلىدە ئىلگىرىكى كودلارنى كۆرەلمەيسىز";
  $MSG_BBS_NOT_ALLOWED_FOR_EXAM="ئىمتاھان مەزگىلىدە مۇنازىرىلىشىشكە بولمايدۇ";
  $MSG_MODIFY_NOT_ALLOWED_FOR_EXAM="ئىمتاھان مەزگىلىدە ئابۇنىت ئۇچۇرىنى ئۆزگەرتىشكە بولمايدۇ";
  $MSG_MAIL_NOT_ALLOWED_FOR_EXAM="ئىمتاھان تۈگىمىگىچە ئېلخەت ئىشلىتىشكە بولمايدۇ";
  $MSG_LOAD_TEMPLATE_CONFIRM="ئىلگىرىكى نۇسخىنى چۈشۈرمەكچىمۇ\\n ئۇنداقتا سىز ھازىرقى كودىڭىزنى يۇيۇۋىتىسىز ";
  $MSG_NO_MAIL_HERE="OJ ئىچكى خەت چەك قوللىمايدۇ";
  
  $MSG_BLOCKLY_OPEN="كۆرۈنمە";
  $MSG_BLOCKLY_TEST="كورۈنمە يۈرگۈزۈش";
  $MSG_MY_SUBMISSIONS=" تاپشۇرغىنىم";
  $MSG_MY_CONTESTS=" مۇسابىقەم";
  $MSG_Creator=" چىقارغۇچى ";
  $MSG_IMPORTED=" سىرىتتىن ";
  $MSG_PRINTER="پىرىنتېر ";
  $MSG_PRINT_DONE="پىرىتېرلاش تامام";
  $MSG_PRINT_PENDING=" پىرىتېرنى كۈتۈۋاتىدۇ ";
  $MSG_PRINT_WAITING=" سەۋىرچانلىق بىلەن كۈتۈپ تۇرۇڭ،قايتا بۇيرۇق بەرمەڭ ";
  $MSG_COLOR=" رەڭگى ";
  $MSG_BALLOON=" شار ";
  $MSG_BALLOON_DONE=" شار قويۇۋىتىلدى ";
  $MSG_BALLOON_PENDING=" شار تارقىتىلمىدى ";
  $MSG_DATE="Date";
  $MSG_SIGN="Signature";
  $MSG_RECENT_PROBLEM="Recent Problems";
  $MSG_RECENT_CONTEST="Recent Contest";
  $MSG_PASS_RATE="Pass Rate";
  $MSG_SHOW_TAGS="Show Tags";
  $MSG_SHOW_ALL_TAGS="All Tags";
  $MSG_RESERVED="Reserved";

  $MSG_HELP_SEEOJ="ئالدىنىقى بەتكە قايتىش  ";
  $MSG_HELP_ADD_NEWS="باش بەتكە ئۇقتۇرۇش يېزىش";
  $MSG_HELP_NEWS_LIST=" يېزىلغان ئۇقتۇرۇشلارنى تەھرېرلەش ";
  $MSG_HELP_USER_LIST=" ئابۇنىتچىلارنى باشقۇرۇش ";
  $MSG_HELP_USER_ADD="add user";
  $MSG_HELP_ADD_PROBLEM="ئالدى بىلەن سوئال قوشۇپ،كىيىن سىناق نۇقتىلىرىنى يوللىسىڭىز بولىدۇ ";
  $MSG_HELP_PROBLEM_LIST="قوشۇلۇپ بولغان سوئاللارنى تەھرىرلەش ياكى سىناق نۇقتىلىرىنى ئۆزگەرتىش";
  $MSG_HELP_ADD_CONTEST="مۇسابىقە ئورۇنلاشتۇرۇش.بۇنىڭدا سوئاللارنىڭ نۇمۇرى پەش بىلەن ئايرىلىدۇ.خۇسۇسىي ياكى ئاشكارە تەڭشەشكە،تەكلىپ كودى بىكىتىشكە ،قاتناشقۇچىلارنى بىكىتىشكە بولىدۇ";
  $MSG_HELP_CONTEST_LIST="مۇسابىقىلەر جەدۋىلى. مۇسابىقە ۋاقتىنى ياكى خاراكتېرىنى ئۆزگەرتىشكە تامامەن بولىدۇ،ئەمما مۇسابىقە باشلانغاندىن كىيىن يۇقارقى ئۇچۇرلارنى ئۆزگەرتمەڭ";
  $MSG_HELP_SET_LOGIN_IP="Record computer(login IP) changes during the exam.";
  $MSG_HELP_TEAMGENERATOR="تۈركۈملەپ ھېساب نۇمۇرى چىقىرىش.ئېھتىيات بىلەن ئىشلىتىڭ،ئەخلەت نۇمۇرلارنىڭ چىقىشىدىن ساقلىنىڭ";
  $MSG_HELP_SETMESSAGE="دومىلىما ئۇقتۇرۇش يېزىش";
  $MSG_HELP_SETPASSWORD=" مەخپى نۇمۇرنى قايتا تەڭشەش.باشقۇرغۇچى ئاۋال ئادەتتىكى ئابۇنىتچىغا ئايلىنىشى كىرەك";
  $MSG_HELP_REJUDGE="سوئال،مۇسابىقە،تاپشۇرۇشلارنى قايتا تەكشۈرۈش ";
  $MSG_HELP_ADD_PRIVILEGE="ئالاھېدە ئەزا ياكى ھوقۇق بىكىتىش مەسىلەن: administratorsباشقۇرغۇچى , subjectsكاتىپ , playersئوينىغۇچى, organizersتەشكىللىگۈچى, participantsقاتناشقۇچى, code viewerكود كۆرگۈچى, manual judge questions سوئال بىر تەرەپ قىلىش, remote questions&سوئال يۆتكەش   other permissionsباشقا ھوقوقلار ";
  $MSG_HELP_ADD_CONTEST_USER="Add User to private contest.";
	$MSG_HELP_ADD_SOLUTION_VIEW="Add Problem Solution View for User.";
  $MSG_HELP_PRIVILEGE_LIST= "ئالاھېدە ھوقوق چەكلىمىلەرنى تەڭشەش";
  $MSG_HELP_GIVESOURCE="بەزى ئابۇنىتلارغا ئۆلچەملىك كودنى كۆرۈش ھوقۇقى بىرىش،شۇ ئارقىلىق كودى ئۆتەلمىگەن ئابۇنىت مۇسابىقىدىن كىيىن ئۆلچەملىك كودنى ئۆگىنىشكە ياردەم بىرىش";
  $MSG_HELP_EXPORT_PROBLEM= " ھۆججىتى نۇسخىسىدا چىقىرىپ ساقلاشfps.xml سوئاللارنى ";
  $MSG_HELP_IMPORT_PROBLEM="ھۆججىتى سوئاللىرىنى كىرگۈزۈش ياكى توردىن سوئال ئىزدەش   fps.xml";
  $MSG_HELP_UPDATE_DATABASE= "سان-سىپىر ئامبىرىنى يېڭىلاش (ھەر قېتىم سىستېما يىڭىلىغاندا مۇشۇ بۇيرۇقنى يۈرگۈزۈڭ)";
  $MSG_HELP_ONLINE= "توردىكى ئابۇنىتلارنى كۆرۈش";
  $MSG_HELP_AC="مۇبارەك بولسۇن،كودىڭىز بارلىق سىناق نۇقتىلىرىدىن ئۆتتى. تېخىمۇ تېرىشىڭ";
  $MSG_HELP_PE="جاۋابىڭىز توغرا ئەمما فورماتى خاتا،جاۋابىڭىزنى تەپسىلى كۆررۈپ بېقىڭ.بوش كاتەك،بوش قۇرلار بولماسلىقى كىرەك";
  $MSG_HELP_WA="جاۋابىڭىز خاتا!!! ئۈلگە كىرگۈزۈش چىقىرىشتىنلا ئۆتكەن كود توغرا كود بولۇشى ناتايىن،تېخىمۇ ئىنچىكە ئويلىنىپ بېقىڭ،ئارقا سۇپىدا يەنە باشقا كىرگۈزۈش چىقىرىشلار بار";
  $MSG_HELP_TLE="كودىڭىز بەلگىلەنگەن چەكلىك ۋاقىت ئىچىدە بارلىق سىناق نۇقتىلىرىدىن ئۆتۈپ بولالمىدى";
  $MSG_HELP_MLE="كودىڭىز چەكلىمىدىن يۇقرى ئىچكى ساقلىغۇچ سەرىپ قىلدى";
  $MSG_HELP_OLE="كودىڭىز بەك كۆپ ئۇچۇر چىقاردى،تەپسىلى كۆرۈپ بېقىڭ ،ئادەتتە چىقىرىش 1 مىگابايىتتىن ئاشمايدۇ";
  $MSG_HELP_RE="يۈرۈش خاتا.گەرچە كودىڭىز توغرا تەرجىمە بولۇنسىمۇ،يۈرۈش جەريانىدا خاتالىق كۆرۈلدى.سەۋەبى بەلكىم تۆۋەندىكىچە:قائىدىگە ئىخلاپ ساقلىغۇچ زىيارىتى ياكى ئىندىكىس،چەكلەنگەن فۇنكىسىيەنى ئىشلىتىش،پويىنتېر ئۇچۇپ يۈرۈش ...";
  $MSG_HELP_CE="كودىڭىز تەرجىمىدە مەغلۇپ بولدى.كودىڭىزدا ئېغىر دەرجىدە تىل خاتالىق بار،بۇيەرنى چىكىپ تەپسىلاتىنى كۆرۈڭ";
  
  $MSG_HELP_MORE_TESTDATA_LATER="كۆپلىگەن سىناق نۇقتىلىرىنى سوئال كىرگۈزۈپ بولغاندىن كىيىن قوشۇش";
  $MSG_HELP_ADD_FAQS="Add a news which titled \"faqs.$OJ_LANG\", it apears as <a href=../faqs.php>$MSG_FAQ</a>";
	$MSG_HELP_HUSTOJ="<sub><a target='_blank' href='https://github.com/zhblue/hustoj'><span class='glyphicon glyphicon-heart' aria-hidden='true'></span> Please give us a <span class='glyphicon glyphicon-star' aria-hidden='true'></span>Star @HUSTOJ Github!</a></sub>";
  $MSG_HELP_SPJ="<a href='https://cn.bing.com/search?q=hustoj+special+judge' target='_blank'>ئىزدەڭ hustoj special judge</a>تېخىمۇ كۆپ تەپسىلات ";
  $MSG_HELP_BALLOON_SCHOOL="پىرىنتېر ۋە شار ئۈچۈن مەكتەپ نامى سۈزۈۋىتىلىدۇ";

  $MSG_WARNING_LOGIN_FROM_DIFF_IP="ئادىرىستىن تىزىملاپ كىرىشip ئوخشىمىغان";
  $MSG_WARNING_DURING_EXAM_NOT_ALLOWED=" ئىمتاھان ۋاقتىدا رۇخسەت يوق  ";
  $MSG_WARNING_ACCESS_DENIED="كەچۈرۈڭ، سىز بۇ خەۋەرنى تەكشۈرۈشكە ئامالسىز. چۈنكى ئۇ سىزگە تەۋە ئەمەس، ياكى باشقۇرغۇچى سېستىما ھالىتىنى بەلگىلەپ بۇ تۈردىكى ئۇچۇرلارنى كۆرسەتمەيدۇ.";

  $MSG_WARNING_USER_ID_SHORT="ئابۇنىت نامى كەمىدە 3 ھەرپ";
  $MSG_WARNING_PASSWORD_SHORT="شىفىر كەمىدە 6 ھەرپ";
  $MSG_WARNING_REPEAT_PASSWORD_DIFF="ئىككى شىفىر ماس ئەمەس";
  
  
  $MSG_LOSTPASSWORD_MAILBOX="  دەلىللەش كودىنى ئېلخېتىڭىزگە يوللاندى،تەكشۈرۈپ ئېلىڭ";
  $MSG_LOSTPASSWORD_WILLBENEW=" ئەگەر توغرا بولسا ،كىيىنكى قەدەمدە مۇقۇملاش ئارقىلىق دەلىللەش كودى سىزنىڭ يېڭى مەخپى شىفىرىڭىزگە ئايلىنىدۇ";


  // template/../reinfo.php
  $MSG_A_NOT_ALLOWED_SYSTEM_CALL="سىستېما چەكلىگەن مەشغۇلات سىستېمىسىنى يۆتكەپ ئىشلىتىپ، ھوقۇق دائىرىسىدىن ھالقىپ ھۆججەت ياكى جەريان قاتارلىق بايلىقلارنى زىيارەت قىلغان-قىلمىغانلىقىغا قاراپ بېقىڭ، ئەگەر سىز سىستېما باشقۇرغۇچى بولسىڭىز ھەمدە تاپشۇرغان جاۋابتا مەسىلە يوق، سىناق سانلىق مەلۇماتىدا مەسىلە يوق دەپ جەزىملەشتۈرسىڭىز، RE نى ئۈندىدار كۆپچىلىك نومۇرى onlinejudge غا يوللاپ، ھەل قىلىش لايىھەسىنى كۆرۈپ باقسىڭىز بولىدۇ. ";
  $MSG_SEGMETATION_FAULT="بۆلەك خاتالىقى، سانلار گۇرۇپپىسى پاسىلىدىن ھالقىپ كەتكەن، ئىسترېلكىسى بىنورمال، زىيارەت قىلىشقا تېگىشلىك بولمىغان ئىچكى ساقلىغۇچ رايونىنى زىيارەت قىلغان-قىلمىغانلىقىنى تەكشۈرۈش ";
  $MSG_FLOATING_POINT_EXCEPTION="لەيلىمە نۇقتا خاتالىقى، نۆلنى بۆلۈش ئەھۋالىنىڭ بار-يوقلۇقىنى تەكشۈرۈش. ";
  $MSG_BUFFER_OVERFLOW_DETECTED="بۇففېر رايونى تېشىپ كېتىش، ھەرپ-بەلگە تىزىقى ئۇزۇنلۇقىنىڭ سانلار گۇرۇپپىسىدىن ئېشىپ كەتكەن ياكى كەتمىگەنلىكىنى تەكشۈرۈش. ";
  $MSG_PROCESS_KILLED="جەريان ئىچكى ساقلىغۇچ ياكى ۋاقىت سەۋەبىدىن ئۆلتۈرۈلدى، ئۆلۈك ئايلىنىشنىڭ بار-يوقلۇقى تەكشۈرۈڭ.";
  $MSG_ALARM_CLOCK="جەريان ۋاقىت سەۋەبىدىن ئۆلتۈرۈلۈپ، ئۆلۈك ئايلىنىشنىڭ بار-يوقلۇقى تەكشۈرۈلىدۇ، بۇ خاتالىق ۋاقىت ئېشىپ كەتكەن TLE بىلەن تەڭ قىممەتتە بولىدۇ ";
  $MSG_CALLID_20="بەلكىم سانلار گۇرۇپپىسى پاسىلدىن ھالقىپ كەتكەن بولۇشى مۇمكىن، تەكشۈرۈش تېمىسىدا تەسۋىرلەنگەن سانلىق مەلۇمات مىقدارى بىلەن ئىلتىماس قىلىنغان سانلار گۇرۇپپىسىنىڭ چوڭ-كىچىكلىك مۇناسىۋىتىنى تەكشۈرۈش كېرەك ";
  $MSG_ARRAY_INDEX_OUT_OF_BOUNDS_EXCEPTION="سانلار گۇرۇپپىسىنىڭ چېگرىدىن ئۆتۈش ئەھۋالىنى تەكشۈرۈڭ.";
  $MSG_STRING_INDEX_OUT_OF_BOUNDS_EXCEPTION="ھەرپ-بەلگە تىزىقى ئاستىدىكى بەلگە چېگرادىن ئۆتۈپ، subString, charAt قاتارلىق ئۇسۇللارنىڭ پارامېتىرلىرىنى تەكشۈرۈڭ.";

	// template/../ceinfo.php
	$MSG_ERROR_EXPLAIN="چۈشەنچە";
	$MSG_SYSTEM_OUT_PRINT ="Java دا System.out.print ئىشلىتىش ئۇسۇلى C تىلى printf بىلەن ئوخشىمايدۇ، System.out.format نى سىناپ كۆرۈڭ. ";
	$MSG_NO_SUCH_FILE_OR_DIRECTORY ="مۇلازىمېتىر لىنۇكىس سىستېمىسى بولۇپ ، Windows قا خاس بولغان ئۆلچەمسىز باش ھۆججەتلىرىنى ئىشلىتىشكە بولمايدۇ. ";
	$MSG_NOT_A_STATEMENT ="چوڭ تىرناق {} نى ماسلىشىش ئەھۋالىنى تەكشۈرۈڭ، eclipse كودنى رەتلەش تېز كۇنۇپكىسى Ctrl + Shift + F ";
	$MSG_EXPECTED_CLASS_INTERFACE_ENUM ="java فۇنكىسىيەسىنى (ئۇسۇلى) تۈر باياناتىنىڭ سىرتىغا قويماڭ، چوڭ تىرناقنىڭ ئاخىرلىشىش ئورنىغا دىققەت قىلىڭ. ";
	$MSG_SUBMIT_JAVA_AS_C_LANG ="java پروگراممىسىنى C تىلى قىلىپ تاپشۇرماڭ. ";
	$MSG_DOES_NOT_EXIST_PACKAGE ="ئىملا تەكشۈرۈش، مەسىلەن: سېستىما ئوبىكتى System چوڭ يېزىش S دىن باشلىنىدۇ. ";
	$MSG_POSSIBLE_LOSS_OF_PRECISION ="مەجبۇرىي قىممەت بېرىش ئېنىقلىق دەرىجىسىنى يوقىتىدۇ، سانلىق مەلۇمات تۈرىنى تەكشۈرۈڭ، ئەگەر خاتالىق يوقلۇقى بېكىتىلسە، مەجبۇرىي تىپىنى ئالماشتۇرلىدۇ. ";
	$MSG_INCOMPATIBLE_TYPES ="Java دىكى ئوخشىمىغان تۈردىكى سانلىق مەلۇماتلارغا ئۆز ئارا قىممەت بەرگىلى بولمايدۇ، پۈتۈن ساننى بور قىممىتى قىلغىلى بولمايدۇ. ";
	$MSG_ILLEGAL_START_OF_EXPRESSION ="ھەرپ-بەلگە تىزىقىنى ئىنگلىزچە قوش تىرناق (/) دىن پايدىلىنىپ كەلتۈرۈپ چىقىرىدۇ. ";
	$MSG_CANNOT_FIND_SYMBOL ="ئىملا خاتالىقى ياكى يۆتكەپ ئىشلىتىش فونكسىيىسى كەمچىل بولغان ئوبيېكتلار، مەسىلەن () System. out نى يۆتكەپ ئىشلىتىشكە توغرا كېلىدۇ. ";
	$MSG_EXPECTED_SEMICOLON ="چېكىت كام.";
	$MSG_DECLARED_JAVA_FILE_NAMED ="Java چوقۇم public class Main نى ئىشلىتىش كېرەك. ";
	$MSG_EXPECTED_WILDCARD_CHARACTER_AT_END_OF_INPUT ="كود ئاخىرلاشمىدى، ماس كېلىدىغان تىرناق ياكى چېكىتلىك پەش كەم، كۆچۈرگەندە بارلىق كودنى تاللىغان-تاللىمىغانلىقىنى تەكشۈرۈڭ.";
	$MSG_INVALID_CONVERSION ="يوشۇرۇن تىپ ئالماشتۇرۇش ئىناۋەتسىز، كۆرسىتىلگەن مەجبۇرىي تىپ ئارقىلىق (int* )malloc(...)";
	$MSG_NO_RETURN_TYPE_IN_MAIN ="+ C ئۆلچىمىدە، main فۇنكسىيەسىنىڭ چوقۇم قايتىش قىممىتى بولۇشى كېرەك. ";
	$MSG_NOT_DECLARED_IN_SCOPE ="ئۆزگەرگۈچى مىقدار بايانات ئېلان قىلىپ باقمىغان، ئىملا خاتالىقىنى تەكشۈرۈپ بېقىڭ! ";
	$MSG_MAIN_MUST_RETURN_INT ="ئۆلچەملىك C تىلىدا، main فۇنكىسىيەسىنىڭ قايتىش قىممىتى تىپى چوقۇم int بولۇشى كېرەك، دەرسلىك ۋە VC دا void غەيرى ئۆلچەملىك ئىشلىتىش ئۇسۇلى قوللىنىلىدۇ. ";
	$MSG_PRINTF_NOT_DECLARED_IN_SCOPE ="printf فونكىسىيىسى بايانات ئېلان قىلمايلا يۆتكەپ ئىشلىتىلدى، stdio. h ياكى cstdio باش ھۆججىتىنى كىرگۈزدىمۇ يوق؟ ";
	$MSG_IGNOREING_RETURN_VALUE ="ئاگاھلاندۇرۇش: فۇنكسىيەنىڭ قايتىش قىممىتىگە سەل قارالسا، بەلكىم فۇنكسىيە خاتا ئىشلىتىلگەن ياكى قايتىش قىممىتىنىڭ نورمالسىزلىقىنى ئويلاشمىغان بولۇشى مۇمكىن ";
	$MSG_NOT_DECLARED_INT64 ="-int64 دە بايانات يوق، ئۆلچەملىك C/C + دا مىكروسوفتنىڭ VCدىكى int64 نى قوللىمايدۇ، long long ئىشلىتىپ 64 خانىلىق ئۆزگەرگۈچى مىقدارنى بايان قىلىڭ. ";
	$MSG_EXPECTED_SEMICOLON_BEFORE ="ئالدىنقى قۇردا ئايرىش چېكتى كام.";
	$MSG_UNDECLARED_NAME ="ئۆزگەرگۈچى مىقدارنى ئىشلىتىشتىن بۇرۇن چوقۇم ئاۋۋال بايانات ئېلان قىلىش كېرەك، بەلكىم ئىملا خاتالىقى بولۇشى مۇمكىن، چوڭ-كىچىك قىلىپ پەرقلەندۈرۈشكە دىققەت قىلىش كېرەك. ";
	$MSG_SCANF_NOT_DECLARED_IN_SCOPE ="scanf فۇنكىسىيەسى ئېنىقلىما بېرىلمىدى، stdio.h ياكى cstdio باش ھۆججىتىنى كىرگۈزگەن-كىرگۈزمىگەنلىكىنى تەكشۈرۈڭ. ";
	$MSG_MEMSET_NOT_DECLARED_IN_SCOPE ="memset فۇنكىسىيەسى ئېنىقلىما بېرىلمىدى، stdlib.h ياكى cstdlib باش ھۆججىتىنى كىرگۈزگەن-كىرگۈزمىگەنلىكىنى تەكشۈرۈڭ. ";
	$MSG_MALLOC_NOT_DECLARED_IN_SCOPE ="malloc فۇنكىسىيەسى ئېنىقلىما بېرىلمىدى، stdlib.h ياكى cstdlib باش ھۆججىتىنى كىرگۈزگەن-كىرگۈزمىگەنلىكىنى تەكشۈرۈڭ. ";
	$MSG_PUTS_NOT_DECLARED_IN_SCOPE ="puts فۇنكىسىيەسى ئېنىقلىما بېرىلمىدى، stdio.h ياكى cstdio باش ھۆججىتىنى كىرگۈزگەن-كىرگۈزمىگەنلىكىنى تەكشۈرۈڭ. ";
	$MSG_GETS_NOT_DECLARED_IN_SCOPE ="gets فۇنكىسىيەسى ئېنىقلىما بېرىلمىدى، stdio.h ياكى cstdio باش ھۆججىتىنى كىرگۈزگەن-كىرگۈزمىگەنلىكىنى تەكشۈرۈڭ. ";
	$MSG_STRING_NOT_DECLARED_IN_SCOPE ="string فۇنكىسىيەسى ئېنىقلىما بېرىلمىدى، string.h ياكى cstring باش ھۆججىتىنى كىرگۈزگەن-كىرگۈزمىگەنلىكىنى تەكشۈرۈڭ. ";
	$MSG_NO_TYPE_IMPORT_IN_C_CPP ="Java تىل پروگراممىسىنى C/C + + قىلىپ تاپشۇرماڭ، تاپشۇرۇشتىن بۇرۇن تىل تىپىنى تاللاشقا دىققەت قىلىڭ. ";
	$MSG_ASM_UNDECLARED ="C/C + نىڭ ئىچىگە ئاسسېمبل تىلى كودىنى كىرگۈزۈشكە بولمايدۇ. ";
	$MSG_REDEFINITION_OF ="فۇنكىسىيە ياكى ئۆزگەرگۈچى مىقدار تەكرار ئېنىقلىما بېرىپ، كودنى كۆپ قېتىم چاپلىغان ياكى چاپلىمىغانلىقىغا قاراپ بېقىڭ. ";
	$MSG_EXPECTED_DECLARATION_OR_STATEMENT ="پروگرامما يېزىلىپ بولمىغان ئوخشايدۇ، كۆچۈرۈپ چاپلىغاندا كودىنى چۈشۈرۈپ قويغان ياكى قويمىغانلىقىغا قاراپ بېقىڭ. ";
	$MSG_UNUSED_VARIABLE ="ئەسكەرتىش: ئۆزگەرگۈچى مىقدار ئېنىقلىما بېرىلگەندىن كېيىن ئىشلىتىلمىدى، ئىملا خاتالىقىنىڭ بار-يوقلۇقى تەكشۈرۈڭ، نامى ئوخشاپ كېتىدىغان ئۆزگەرگۈچى مىقدار خاتا ئىشلىتىلدىمۇ يوق؟";
	$MSG_IMPLICIT_DECLARTION_OF_FUNCTION ="فۇنكسىيە يوشۇرۇن باياناتى، تەكشۈرۈش ئاستىدا توغرا بولغان باش ھۆججەت كىرگۈزۈلگەن-كىرگۈزۈلمىگەنلىكىنى تەكشۈرۈش. ياكى تېما تەلەپ قىلغان بەلگىلەنگەن ئىسىمنىڭ فۇنكىسىيەسى كەم بولۇپ قالدى. ";
	$MSG_ARGUMENTS_ERROR_IN_FUNCTION ="فۇنكسىيەنى يۆتكەپ ئىشلەتكەندە تەمىنلىگەن پارامېتىرنىڭ سانى توغرا بولمىسا، پارامېتىرنى خاتا ئىشلەتكەن-ئىشلەتمىگەنلىكىنى تەكشۈرۈش كېرەك. ";
	$MSG_EXPECTED_BEFORE_NAMESPACE ="C پىلوس + تىل پروگراممىسىنى C غا تاپشۇرماڭ، تاپشۇرۇشتىن بۇرۇن تىل تۈرىنى تاللاشقا دىققەت قىلىڭ. ";
	$MSG_STRAY_PROGRAM ="جۇڭگو يېزىقىدىكى بوش ئورۇن، تىنىش بەلگىلىرى پروگراممىدا ئىزاھلانغان ۋە ھەرپ-بەلگە تىزىقىدىن باشقا قىسىملاردا كۆرۈلسە بولمايدۇ. پروگرامما تۈزگەندە خەنزۇچە خەت كىرگۈزگۈچنى ئېتىۋېتىڭ. توردا كۆچۈرۈپ كەلگەن كودنى ئىشلەتمەڭ. ";
	$MSG_DIVISION_BY_ZERO ="نۆلنى بۆلگەندە لەيلىمە نۇقتىنىڭ تېشىپ كېتىشىنى كەلتۈرۈپ چىقاردى.";
	$MSG_CANNOT_BE_USED_AS_A_FUNCTION ="ئۆزگەرگۈچى مىقدارنى فونكىسىيە ئورنىدا ئىشلەتكىلى بولمايدۇ، ئۆزگەرگۈچى مىقدار نامى ۋە فونكىسىيە نامى تەكرارلىنىش ئەھۋالىنى تەكشۈرۈش بەلكىم ئىملا خاتالىقى بولۇشى مۇمكىن. ";
	$MSG_CANNOT_FIND_TYPE ="scanf/printfنىڭ فورمات تەسۋىرى كېيىنكى پارامېتىر جەدۋىلى بىلەن بىردەك ئەمەس، ئادرېس ئېلىش بەلگىسى« & » نى ئارتۇق ياكى ئاز ئېلىشمۇ ئىملا خاتالىقى بولۇشى مۇمكىن. ";
	$MSG_JAVA_CLASS_ERROR ="Java تىلىدا پەقەت بىرلا public تۈرى بار، ھەمدە تۈر نامى چوقۇم Main بولۇشى كېرەك، باشقا تۈرلەردە public ئاچقۇچلۇق سۆزىنى ئىشلەتمەڭ. ";
	$MSG_EXPECTED_BRACKETS_TOKEN ="ئوڭ تىرناق كەم";
	$MSG_NOT_FOUND_SYMBOL ="ئېنىقلىمىسىز فۇنكسىيە ياكى ئۆزگەرگۈچى مىقدار ئىشلىتىلگەن، ئىملادا خاتالىق بار-يوقلۇقى تەكشۈرۈڭ، مەۋجۇت بولمىغان فۇنكسىيەنى ئىشلەتمەڭ، Java يۆتكەپ ئىشلىتىش ئۇسۇلى ئادەتتە ئوبيېكت نامى قوشۇلىدۇ، مەسىلەن list1.add(some..) ئۇسۇلىنى يۆتكەپ ئىشلەتكەندە پارامېتىر تىپىغا سەزگۈر، مەسىلەن: پۈتۈن سان (int) نى ھەرپ-بەلگە تىزىقىنى قوبۇل قىلىش ئوبيېكتى (String) غا يەتكۈزۈپ بەرمەسلىك كىرەك.";
	$MSG_NEED_CLASS_INTERFACE_ENUM ="ئاچقۇچلۇق سۆز كەم، class، interfac ياكى enum دەپ ئېلان قىلىش كېرەك ";
	$MSG_CLASS_SYMBOL_ERROR ="دەرسلىكتىكى مىساللارنى ئىشلەتكەندە، چوقۇم مۇناسىۋەتلىك تۈردىكى كودنى قوشۇپ تاپشۇرۇش، شۇنىڭ بىلەن بىر ۋاقىتتا ئۇنىڭدىكى public ئاچقۇچلۇق سۆزىنى چىقىرىۋېتىش كېرەك ";
	$MSG_INVALID_METHOD_DECLARATION ="پەقەت تۈر نامى بىلەن ئوخشاش ئۇسۇل قۇرۇلما ئۇسۇلى بولۇپ، قايتىش قىممىتى تىپى يېزىلمايدۇ. ئەگەر تۈر نامى Main دەپ ئۆزگەرتىلسە، قۇرۇلما ئۇسۇلىنىڭ نامىنى بىرلا ۋاقىتتا ئۆزگەرتىڭ. ";
	$MSG_EXPECTED_AMPERSAND_TOKEN ="C پىلوس + تىل پروگراممىسىنى C غا تاپشۇرماڭ، تاپشۇرۇشتىن بۇرۇن تىل تۈرىنى تاللاشقا دىققەت قىلىڭ. ";
	$MSG_DECLARED_FUNCTION_ORDER ="فۇنكىسىيە، ئۇسۇل باياناتىنىڭ ئالدى-كەينىدىكى تەرتىپلەرگە دىققەت قىلىڭ، بىر ئۇسۇل ئىچىدە يەنە بىر ئۇسۇلنىڭ باياناتىنى چىقارغىلى بولمايدۇ. ";
	$MSG_NEED_SEMICOLON ="يۇقىرىدا ئەسكەرتىلگەن بۇ قۇرنىڭ ئەڭ ئاخىرىدا ئايرىما چېكىت كەم. ";
	$MSG_EXTRA_TOKEN_AT_END_OF_INCLUDE ="include جۈملىسى چوقۇم بىر قۇر مۇستەقىل بولۇشى، كەينىدىكى جۈملىلەر بىلەن بىر قۇرغا قويۇلماسلىقى كېرەك. ";
	$MSG_INT_HAS_NEXT ="hasNext () نى next Int () غا ئۆزگەرتىش كېرەك. ";
	$MSG_UNTERMINATED_COMMENT ="ئىزاھات ئاخىرلاشمىدى، « /* » غا ماس كېلىدىغان ئاخىرلاشتۇرۇش بەلگىسى« /* » نىڭ توغرا ياكى ئەمەسلىكىنى تەكشۈرۈڭ ";
	$MSG_EXPECTED_BRACES_TOKEN ="فۇنكسىيە باياناتىدا كىچىك تىرناق () كەم بولۇپ قالغان، مەسىلەن () int main دەپ يېزىلىپ قالغان. ";
	$MSG_REACHED_END_OF_FILE_1 ="تاپشۇرغان ئەسلى كودنى تولۇق كۆچۈرمىگەن ياكى ئاخىرلاشقان چوڭ تىرناق كەم بولۇپ قالغان-قالمىغانلىقىنى تەكشۈرۈڭ";
	$MSG_SUBSCRIPT_ERROR ="سانلار گۇرۇپپىسى ياكى ئىسترېلكىسىز ئۆزگەرگۈچى مىقدارغا قارىتا زىيارەت قىلىشقا بولمايدۇ. ";
	$MSG_EXPECTED_PERCENT_TOKEN ="scanf نىڭ فورمات قىسمىنى قوش تىرناق ئارقىلىق كەلتۈرۈپ چىقىرىشقا توغرا كېلىدۇ. ";
	$MSG_EXPECTED_EXPRESSION_TOKEN ="پارامېتىر ياكى ئىپادىلەش شەكلىنى يېزىپ بولالمىدى";
	$MSG_EXPECTED_BUT ="خاتا بەلگە ياكى ھەرپ";
	$MSG_REDEFINITION_MAIN ="بۇ تېما بەلكىم قوشۇمچە كود سوئالى بولۇشى مۇمكىن، تېمىنى قايتا كۆرۈپ، سوئالنىڭ مەنىسىنى ئېنىق كۆرۈڭ، سىستېما ئېنىقلىما بېرىپ بولغان main فۇنكىسىيەسىنى تاپشۇرماڭ، بەلكى بەلگىلەنگەن فورماتنىڭ مەلۇم فۇنكىسىيەسىنى تاپشۇرىشىڭىز كېرەك. ";
	$MSG_IOSTREAM_ERROR ="C پىلوس + پروگراممىسىنى C غا تاپشۇرماڭ. ";
	$MSG_EXPECTED_UNQUALIFIED_ID_TOKEN ="سانلار گۇرۇپپىسى باياناتىدىن كېيىن چېكىت پەش كەم بولۇپ قالغان-قالمىغانلىقىغا دىققەت قىلىش كېرەك. ";
	$MSG_REACHED_END_OF_FILE_2 ="پروگرامما ئاخىرىدا چوڭ تىرناق كەم";
	$MSG_INVALID_SYMBOL ="خەنزۇچە تىنىش بەلگىسى ياكى بوش ئورۇن ئىشلەتكەن-ئىشلەتمىگەنلىكىنى تەكشۈرۈڭ.";
	$MSG_DECLARED_FILE_NAMED ="OJ دىكى public تۈرى پەقەت Main. ";
	$MSG_EXPECTED_IDENTIFIER ="ئۆزگەرگۈچى مىقدارنى ئەسكەرتكەندە، ئۆزگەرگۈچى مىقدارنىڭ نامىنى ئەسكەرتمەسلىك ياكى تىرناق كەم بولۇش مۇمكىن. ";
	$MSG_VARIABLY_MODIFIED ="سانلار گۇرۇپپىسىنىڭ چوڭ-كىچىكلىكىدە ئۆزگەرگۈچى مىقدار ئىشلىتىشكە بولمايدۇ، C تىلدا ئۆزگەرگۈچى مىقدارنى ئومۇمىي سانلار گۇرۇپپىسىنىڭ ئۆلچىمى قىلىشقا بولمايدۇ، const ئۆزگەرگۈچى مىقدارنى ئۆز ئىچىگە ئالىدۇ ";
	$MSG_FUNCTION_GETS_REMOVIED ="std: gets بولسا C++11 دىن تاشلىۋېتىلىپ، C++14 دىن چىقىرىۋېتىلىدۇ. std::fgets نى ئىشلىتىشكە بولىدۇ. ياكى ماكرو ئېنىقلىما #define gets(S) fgets(S,sizeof(S),stdin)";
	$MSG_PROBLEM_USED_IN ="سۇئال ئاللىقاچان شەخسىي مۇسابىقىدە ئىشلىتىلدى. ";
	$MSG_MAIL_CAN_ONLY_BETWEEN_TEACHER_AND_STUDENT="Mails can only be sent between teachers and student, not between students.";

	$MSG_REFRESH_PRIVILEGE="ئىمتىيازنى يېڭىلاش";

	$MSG_SAVED_DATE="Saved Date";
	$MSG_PROBLEM_STATUS="Problem Status";
	
	$MSG_NEW_CONTEST="New Contest";
	$MSG_AVAILABLE="Available";

	$MSG_NEW_PROBLEM_LIST="NewProblemList";
	$MSG_DELETE="Delete";
	$MSG_EDIT="Edit";
	$MSG_TEST_DATA="TestData";
	$MSG_CHECK_TO="Batch Operation";

	//bbcode.php
	$MSG_TOTAL="Total";
	$MSG_NUMBER_OF_PROBLEMS="Problems";

	$MSG_SUBMIT_RECORD="Submit Record";
	$MSG_RETURN_CONTEST="Return to contest";
	$MSG_COPY="Copy";
	$MSG_SUCCESS="Success";
	$MSG_FAIL="Fail";
	$MSG_TEXT_COMPARE="Text Compare";
	$MSG_JUDGE_STYLE="Judge Style";
	// reinfo.php 
	$MSG_ERROR_INFO="Runtime information";
	$MSG_INFO_EXPLAINATION="Explaination";
	// ceinfo.php
	$MSG_COMPILE_INFO="Compile information";
	$MSG_SOURCE_CODE="Source code";
	//contest.php
	$MSG_Contest_Pending="Pending";
	$MSG_Server_Time="Server Current Time";
	$MSG_Contest_Infomation="Contest Information";
	// sourcecompare.php
	$MSG_Source_Compare="Source Code Comparation";
	$MSG_BACK="Return to Last Page";
 ?>
