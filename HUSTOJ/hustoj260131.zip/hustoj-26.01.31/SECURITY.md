# Security Policy

## Supported Versions

所有版本都推荐更新到最新版。

如果Ubuntu的版本小于22.04，建议先备份数据。
系统更新到22.04或者24.04后还原数据。

## Reporting a Vulnerability

Use this section to tell people how to report a vulnerability.

Tell them where to go, how often they can expect to get an update on a
reported vulnerability, what to expect if the vulnerability is accepted or
declined, etc.

如有安全相关的问题，请报告至 10982766@qq.com
