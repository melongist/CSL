# HUSTOJ

> 流行的OJ系统，跨平台、易安装、有题库。

[Github](https://github.com/zhblue/hustoj)
[Get Started](/README)
