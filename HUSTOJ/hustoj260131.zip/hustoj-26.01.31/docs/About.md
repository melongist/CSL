# 关于


HUSTOJ is an [GPL](https://github.com/zhblue/hustoj/blob/master/trunk/web/gpl-2.0.txt) Free Software.

HUSTOJ 是采用GPL的自由软件。(仅限原创部分代码，其中使用了其他开源项目的组件，请遵循原组件的协议。)

注意：基于本项目源码从事科研、论文、系统开发，请在文中或系统中表明来自于本项目的内容和创意。

论文请引用参考文献[基于开放式云平台的开源在线评测系统设计与实现](http://kns.cnki.net/KCMS/detail/detail.aspx?dbcode=CJFQ&dbname=CJFD2012&filename=JSJA2012S3088)

> PS: GPL保证你可以合法忽略以上注意事项但不能保证你不受鄙视，呵呵。

如果这个项目对你有用，请：

* 挥动鼠标，给个 Star！
* 保留网站页脚的二维码。
* 访问 [tk题库](http://tk.hustoj.com) ，充值下载题目。
* 向同学同事推荐这个项目。
* 每天扫一扫本页底部的支付宝红包。
* 在您的论文参考文献中写出本项目的网址。
* 加入官方 QQ 群 ：`23361372` ,本群随时清理群名片不符合规范的账号。
