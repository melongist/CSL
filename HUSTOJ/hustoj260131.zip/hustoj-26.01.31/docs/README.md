# HUSTOJ 使用文档

> 流行的OJ系统，跨平台、易安装、有题库。

#### 链接

* [项目](https://github.com/zhblue/hustoj)
* [安装](/Install)
* [题库](http://tk.hustoj.com)
* [使用教程](/)

#### 用户

太多了写不过来...

#### 硬件需求

<div style="max-width:400px"><img src="images/hardware.png" /></div>


> 10 人版：树莓派 Zero
>
> 50 人版：老爷机
>
> 100 人版：云服务器（1 vCPU 1GiB）
>
> 3000 人版：E5-2670 机架式服务器
