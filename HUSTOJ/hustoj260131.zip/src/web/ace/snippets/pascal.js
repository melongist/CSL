ace.define("ace/snippets/pascal",[], function(require, exports, module) {
"use strict";

exports.snippetText = "";
exports.scope = "pascal";

});
                (function() {
                    ace.require(["ace/snippets/pascal"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            