/*	This file is part of the software similarity tester SIM.
	Written by Dick Grune, Vrije Universiteit, Amsterdam.
	$Id: lex.c,v 1.9 2012-06-08 16:04:28 dick Exp $
*/

/* The service macros for the *lang.l files do not require code */

#include	"lex.h"
