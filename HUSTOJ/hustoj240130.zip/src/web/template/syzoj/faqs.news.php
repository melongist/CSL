<?php $show_title="$MSG_FAQ - $OJ_NAME"; ?>
<?php include("template/$OJ_TEMPLATE/header.php");?>
<div class="padding">
    <h1 class="ui center aligned header">帮助</h1>
    <div style="font-content">
             <?php echo $view_faqs?>
    </div>
</div>

<?php include("template/$OJ_TEMPLATE/footer.php");?>
