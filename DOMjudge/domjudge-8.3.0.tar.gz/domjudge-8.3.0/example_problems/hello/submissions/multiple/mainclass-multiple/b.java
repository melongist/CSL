import java.io.*;

public class b {
	public static void main(String[] args) {
		System.out.println("Hello world, this is class B!");
	}
};
