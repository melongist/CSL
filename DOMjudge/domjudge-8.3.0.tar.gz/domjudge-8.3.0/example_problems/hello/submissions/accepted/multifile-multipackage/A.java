package foo.bar.a;

public class A {
	public static void foo() {
		System.out.println("Hello world!");
	}
}
