# This should give CORRECT on the default problem 'hello'.
#
# @EXPECTED_RESULTS@: CORRECT

cat("Hello World!\n")
