'''
@EXPECTED_RESULTS@: RUN-ERROR
'''

raise Exception("Expected failure")
