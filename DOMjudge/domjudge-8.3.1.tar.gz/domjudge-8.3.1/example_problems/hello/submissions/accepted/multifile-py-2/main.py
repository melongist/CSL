'''
This is a multi-file submission which produces two public classes.
Note that to successfully compile, the source file names must be
preserved to match the public class names.

@EXPECTED_RESULTS@: CORRECT
'''

import message

foo = message.Message();
foo.myPrint();
