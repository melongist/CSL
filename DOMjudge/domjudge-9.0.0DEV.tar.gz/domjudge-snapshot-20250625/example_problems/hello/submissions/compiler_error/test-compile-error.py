# @EXPECTED_RESULTS@: COMPILER-ERROR

This is not correct Python syntax and will give errors!
