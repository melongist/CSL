// Extra included file with JS code
// See the misspelling of let into letter.
export function hello() {
    letter unused = 1
    return "Hello world!"
}
