// Extra included file with (invalid) JS code.
// Invalid syntax on import instead of export.
// The file itself is never used in the submission.
import function hello() {
    return "Hello world!"
}
