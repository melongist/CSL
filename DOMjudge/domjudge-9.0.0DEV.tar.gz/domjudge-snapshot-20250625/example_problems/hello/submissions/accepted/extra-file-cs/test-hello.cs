/*
 * This should give CORRECT on the default problem 'hello',
 * since the random extra file will not be passed.
 *
 * @EXPECTED_RESULTS@: CORRECT
 */

using System;

public class Hello
{
	public static void Main(string[] args)
	{
		Console.Write("Hello world!\n");
	}
}
