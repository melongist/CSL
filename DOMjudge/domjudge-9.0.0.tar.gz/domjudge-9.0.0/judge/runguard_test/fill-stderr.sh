#!/bin/bash

while true; do
	echo "DOMjudge" >&2
done
