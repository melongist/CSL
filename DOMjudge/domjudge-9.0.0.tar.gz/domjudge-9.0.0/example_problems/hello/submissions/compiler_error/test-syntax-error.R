# This should give COMPILER-ERROR on the default problem 'hello'.
#
# @EXPECTED_RESULTS@: COMPILER-ERROR

cat("Missing closing bracket!\n"
