// Extra included file with JS code
export function hello() {
    return "Hello world!";
}
